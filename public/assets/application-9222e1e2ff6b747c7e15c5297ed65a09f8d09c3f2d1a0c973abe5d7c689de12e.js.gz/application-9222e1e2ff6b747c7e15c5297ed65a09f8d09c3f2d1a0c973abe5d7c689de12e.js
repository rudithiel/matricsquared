(function() {
  $(document).on('turbolinks:ready', function() {
    return alert("ready");
  });

}).call(this);
